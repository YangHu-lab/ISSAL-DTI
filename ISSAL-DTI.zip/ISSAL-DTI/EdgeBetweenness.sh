#!/bin/bash

# please confirm cold/warm start in the scenario(e.g. cold start)

cd DTI-Prediction
python create_sample.py --input ../data/DownStreamdata/DTInet.txt --offset 1

cd ../SSLPretask
python encode_feature.py --downstream DTI --scenario warm --dataclean 1

python EdgeBetweenness.py --downstream DTI --scenario warm --dataclean 1

python create_dataset.py --input_file ../data/PreTaskdata/EdgeBetweenness.txt

cd ../ISSAL
python Model/train_edge_reg.py --train_file ../data/PreTaskdata/EdgeBetweenness_train.txt --test_file ../data/PreTaskdata/EdgeBetweenness_test.txt --save EdgeBetweenness_warm  --batch_size 128 --nclass 4 --mode 1  --ntask 1 --task 0 --lr 5e-4 --epochs 1 >>EdgeBetweenness_warm/EdgeBetweenness_warm.log

for ((i = 1; i <= 30; i++)); do
  rnd=$(($RANDOM % 3))
  case $rnd in
  0)
    python Model/train_edge_reg.py --train_file ../data/PreTaskdata/EdgeBetweenness_train.txt --test_file ../data/PreTaskdata/EdgeBetweenness_test.txt --save EdgeBetweenness_warm --share EdgeBetweenness_warm --private EdgeBetweenness_warm --batch_size 128  --nclass 4 --mode 1 --ntask 1 --task 0 --lr 5e-4 --epochs 1 >>EdgeBetweenness_warm/EdgeBetweenness_warm.log
    ;;
  1)
      python Model/train_edge_reg.py --train_file ../data/PreTaskdata/EdgeBetweenness_train.txt --test_file ../data/PreTaskdata/EdgeBetweenness_test.txt --save EdgeBetweenness_warm --share EdgeBetweenness_warm --private EdgeBetweenness_warm --batch_size 128  --nclass 4 --mode 1 --ntask 1 --task 0 --lr 5e-4 --epochs 1 >>EdgeBetweenness_warm/EdgeBetweenness_warm.log
    ;;
  2)
      python Model/train_edge_reg.py --train_file ../data/PreTaskdata/EdgeBetweenness_train.txt --test_file ../data/PreTaskdata/EdgeBetweenness_test.txt --save EdgeBetweenness_warm --share EdgeBetweenness_warm --private EdgeBetweenness_warm --batch_size 128  --nclass 4 --mode 1 --ntask 1 --task 0 --lr 5e-4 --epochs 1 >>EdgeBetweenness_warm/EdgeBetweenness_warm.log
    ;;
  esac
done

python Model/GetFeature.py --model EdgeBetweenness_warm --length 1  --save EdgeBetweenness_warm

cd ../DTI-Prediction

python warm_start.py --input_file ../data/DownStreamdata/DTInet_sample.txt --feature ../ISSAL/EdgeBetweenness_warm/feature_EdgeBetweenness_warm.pt --lr 0.002 --epochs 30 --save DTInet/EdgeBetweenness_warm >>Warm_Start/EdgeBetweenness_warm

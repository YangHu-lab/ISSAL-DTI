#!/bin/bash

# please confirm cold/warm start in the scenario(e.g. cold start)

cd DTI-Prediction
python create_sample.py --input ../data/DownStreamdata/DTInet.txt --offset 1

cd ../SSLPretask

python encode_feature.py --downstream DTI --scenario cold --dataclean 1

python TriangleNum.py --downstream DTI --scenario cold --dataclean 1

python create_dataset.py --input_file ../data/PreTaskdata/TriangleNum.txt

cd ../ISSAL
python Model/train_network_reg.py --train_file ../data/PreTaskdata/TriangleNum_train.txt --test_file ../data/PreTaskdata/TriangleNum_test.txt --save TriangleNum_cold --batch_size 128 --mode 1 --nclass 4 --ntask 1 --task 0 --lr 5e-4 --epochs 1 >>TriangleNum_cold/TriangleNum_cold.log

for ((i = 1; i <= 30; i++)); do
  rnd=$(($RANDOM % 3))
  case $rnd in
  0)
    python Model/train_network_reg.py --train_file ../data/PreTaskdata/TriangleNum_train.txt --test_file ../data/PreTaskdata/TriangleNum_test.txt --save TriangleNum_cold --share TriangleNum_cold --private TriangleNum_cold --batch_size 128 --mode 1 --nclass 4 --ntask 1 --task 0 --lr 5e-4 --epochs 1 >>TriangleNum_cold/TriangleNum_cold.log
    ;;
  1)
    python Model/train_network_reg.py --train_file ../data/PreTaskdata/TriangleNum_train.txt --test_file ../data/PreTaskdata/TriangleNum_test.txt --save TriangleNum_cold --share TriangleNum_cold --private TriangleNum_cold --batch_size 128 --mode 1 --nclass 4 --ntask 1 --task 0 --lr 5e-4 --epochs 1 >>TriangleNum_cold/TriangleNum_cold.log
    ;;
  2)
    python Model/train_network_reg.py --train_file ../data/PreTaskdata/TriangleNum_train.txt --test_file ../data/PreTaskdata/TriangleNum_test.txt --save TriangleNum_cold --share TriangleNum_cold --private TriangleNum_cold --batch_size 128 --mode 1 --nclass 4 --ntask 1 --task 0 --lr 5e-4 --epochs 1 >>TriangleNum_cold/TriangleNum_cold.log
    ;;
  esac
done
#
###
python Model/GetFeature.py --model TriangleNum_cold --length 1 --save TriangleNum_cold

cd ../DTI-Prediction

python cold_start.py --input_file ../data/DownStreamdata/DTInet_sample.txt --feature ../ISSAL/TriangleNum_cold/feature_TriangleNum_cold.pt --lr 0.002 --epochs 30 --save DTInet/TriangleNum_cold >>Cold_Start/TriangleNum_cold

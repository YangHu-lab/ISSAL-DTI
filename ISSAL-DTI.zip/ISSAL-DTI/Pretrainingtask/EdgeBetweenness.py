# _*_ coding : utf-8 _*_
# @Author : Yang
# @File : BetCentrality
# @Project : ISSAL-DTI

import numpy as np
import random
import datetime
import networkx as nx
from networkx.algorithms.centrality.betweenness import _single_source_shortest_path_basic, \
    _single_source_dijkstra_path_basic, _accumulate_endpoints, _accumulate_basic, _rescale, _add_edge_keys, \
    _accumulate_edges
from networkx.algorithms.centrality.betweenness_subset import _rescale_e

from utils import Biograph
import argparse

path = '../data/'
parser = argparse.ArgumentParser()
parser.add_argument('--downstream', type=str, default='DTI', help='The name of downstream')
parser.add_argument('--scenario', type=str, default='warm', help='The test scenario of downstream')
parser.add_argument('--dataclean', type=int, default=0, help='Whether to remove the test data')

args = parser.parse_args()


def edge_betweenness_centrality(G, k=None, normalized=True, weight=None, seed=None):
    betweenness = dict.fromkeys(G, 0.0)  # b[v]=0 for v in G
    # b[e]=0 for e in G.edges()
    betweenness.update(dict.fromkeys(G.edges(), 0.0))
    if k is None:
        nodes = G
    else:
        nodes = seed.sample(G.nodes(), k)
    for s in nodes:
        # single source shortest paths
        if weight is None:  # use BFS
            S, P, sigma, _ = _single_source_shortest_path_basic(G, s)
        else:  # use Dijkstra's algorithm
            S, P, sigma, _ = _single_source_dijkstra_path_basic(G, s, weight)
        # accumulation
        betweenness = _accumulate_edges(betweenness, S, P, sigma, s)
    # rescaling
    for n in G:  # remove nodes to only return edges
        del betweenness[n]
    betweenness = _rescale_e(
        betweenness, len(G), normalized=normalized, directed=G.is_directed()
    )
    if G.is_multigraph():
        betweenness = _add_edge_keys(G, betweenness, weight=weight)
    return betweenness


def edge_betweenness():
    G, BIONTs = Biograph(args.downstream, args.scenario, args.dataclean)
    betweenness = edge_betweenness_centrality(G)
    node_cent = open(path + "PreTaskdata/EdgeBetweenness.txt", 'w')
    for edge, centrality in betweenness.items():
        node_cent.write(str(edge[0]) + " " + str(edge[1]) + " " + str(centrality) + "\n")


if __name__ == "__main__":
    edge_betweenness()

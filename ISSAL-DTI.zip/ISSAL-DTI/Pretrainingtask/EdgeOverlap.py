# _*_ coding : utf-8 _*_
# @Author : Yang
# @File : EdgeOverlap_cold
# @Project : ISSAL-DTI

import numpy as np
import random
import datetime
import networkx as nx
import math
import argparse
from utils import Biograph


path = '../data/'
parser = argparse.ArgumentParser()
parser.add_argument('--downstream', type=str, default='DTI', help='The name of downstream')
parser.add_argument('--scenario', type=str, default='warm', help='The test scenario of downstream')
parser.add_argument('--dataclean', type=int, default=0, help='Whether to remove the test data.')

args = parser.parse_args()


def edgeOverlap():
    G, BioHNs = Biograph(args.downstream, args.scenario, args.dataclean)
    node_cent = open(path + "PreTaskdata/EdgeOverlap_cold.txt", 'w')
    for i in range(len(G.nodes)):
        if (i <= 3046):
            u_n = G.degree()[i]
            v_n = G.degree()[i + 1]
            t_n = G.degree()[i + 2]
            C_n = len(list(nx.common_neighbors(G, i, i + 1)))
            D_n = len(list(nx.common_neighbors(G, i, i + 3)))
            E_n = len(list(nx.common_neighbors(G, i + 1, i + 3)))

            if u_n - 1 + v_n - 1 - C_n == 0:
                node_cent.write(str(i) + " " + str(i + 1) + " " + "0" + "\n")
            else:
                node_cent.write(str(i) + " " + str(i + 1) + " " + str(C_n / (u_n - 1 + v_n - 1 - C_n)) + "\n")

            if u_n - 1 + t_n - 1 - D_n == 0:
                node_cent.write(str(i) + " " + str(i + 3) + " " + "0" + "\n")
            else:
                node_cent.write(str(i) + " " + str(i + 3) + " " + str(D_n / (u_n - 1 + t_n - 1 - D_n)) + "\n")

            if v_n - 1 + t_n - 1 - E_n == 0:
                node_cent.write(str(i + 1) + " " + str(i + 3) + " " + "0" + "\n")
            else:
                node_cent.write(str(i + 1) + " " + str(i + 3) + " " + str(E_n / (v_n - 1 + t_n - 1 - E_n)) + "\n")

        else:
            break


if __name__ == "__main__":
    edgeOverlap()

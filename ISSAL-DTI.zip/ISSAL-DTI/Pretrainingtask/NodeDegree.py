# _*_ coding : utf-8 _*_
# @Author : Yang
# @File : DegCentrality
# @Project : ISSAL-DTI

import numpy as np
import random
import datetime
import networkx as nx
import math
import argparse
from utils import Biograph

path = '../data/'
parser = argparse.ArgumentParser()
parser.add_argument('--downstream', type=str, default='DTI', help='The name of downstream')
parser.add_argument('--scenario', type=str, default='warm', help='The test scenario of downstream')
parser.add_argument('--dataclean', type=int, default=0, help='Whether to remove the test data')  #

args = parser.parse_args()


def node_degree():
    G, BIONTs = Biograph(args.downstream, args.scenario, args.dataclean)
    node_cent = open(path + "PreTaskdata/NodeDegree.txt", 'w')
    store_deg = nx.degree(G)
    for i in range(len(G.nodes)):
        node_cent.write(str(i) + " " + str(store_deg[i]) + "\n")

if __name__ == "__main__":
    node_degree()

# _*_ coding : utf-8 _*_
# @Author : Yang
# @File : SquareCluster
# @Project : ISSAL-DTI

import numpy as np
import random
import datetime
import networkx as nx
import math
import argparse
from itertools import combinations

from utils import Biograph

path = '../data/'
parser = argparse.ArgumentParser()
parser.add_argument('--downstream', type=str, default='DTI', help='The name of downstream')
parser.add_argument('--scenario', type=str, default='warm', help='The test scenario of downstream')
parser.add_argument('--dataclean', type=int, default=0, help='Whether to remove the test data from SSL dataset.')  #

args = parser.parse_args()


def square_clustering(G, nodes=None):
    if nodes is None:
        node_iter = G
    else:
        node_iter = G.nbunch_iter(nodes)
    clustering = {}
    for v in node_iter:
        clustering[v] = 0
        potential = 0
        for u, w in combinations(G[v], 2):
            squares = len((set(G[u]) & set(G[w])) - {v})
            clustering[v] += squares
            degm = squares + 1
            if w in G[u]:
                degm += 1
            potential += (len(G[u]) - degm) + (len(G[w]) - degm) + squares
        if potential > 0:
            clustering[v] /= potential
    if nodes in G:
        # Return the value of the sole entry in the dictionary.
        return clustering[nodes]
    return clustering


def squre_clustering():
    G, BIONTs = Biograph(args.downstream, args.scenario, args.dataclean)
    node_cent = open(path + "PreTaskdata/SquareCluster.txt", 'w')
    for i in range(len(G.nodes)):
        node_cent.write(str(i) + " " + str(square_clustering(G, i)) + "\n")


if __name__ == "__main__":
    squre_clustering()

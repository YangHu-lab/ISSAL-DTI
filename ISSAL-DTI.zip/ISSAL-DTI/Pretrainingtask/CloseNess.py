# _*_ coding : utf-8 _*_
# @Author : Yang
# @File : CloseNess
# @Project : ISSAL-DTI

import functools
import numpy as np
import random
import datetime
import networkx as nx
import math
import argparse
from utils import Biograph

path = '../data/'
parser = argparse.ArgumentParser()
parser.add_argument('--downstream', type=str, default='DTI', help='The name of downstream')
parser.add_argument('--scenario', type=str, default='warm', help='The test scenario of downstream')
parser.add_argument('--dataclean', type=int, default=0, help='Whether to remove the test data')

args = parser.parse_args()


def closeness_centrality(G, u=None, distance=None, wf_improved=True):
    if G.is_directed():
        G = G.reverse()  # create a reversed graph view

    if distance is not None:
        # use Dijkstra's algorithm with specified attribute as edge weight
        path_length = functools.partial(
            nx.single_source_dijkstra_path_length, weight=distance
        )
    else:
        path_length = nx.single_source_shortest_path_length

    if u is None:
        nodes = G.nodes
    else:
        nodes = [u]
    closeness_dict = {}
    for n in nodes:
        sp = path_length(G, n)
        totsp = sum(sp.values())
        len_G = len(G)
        _closeness_centrality = 0.0
        if totsp > 0.0 and len_G > 1:
            _closeness_centrality = (len(sp) - 1.0) / totsp
            # normalize to number of nodes-1 in connected part
            if wf_improved:
                s = (len(sp) - 1.0) / (len_G - 1)
                _closeness_centrality *= s
        closeness_dict[n] = _closeness_centrality
    if u is not None:
        return closeness_dict[u]
    return closeness_dict


def clo_centrality():
    G, BIONTs = Biograph(args.downstream, args.scenario, args.dataclean)
    node_cent = open(path + "PreTaskdata/CloseNess.txt", 'w')
    store_clo = closeness_centrality(G)
    for i in range(len(G.nodes)):
        node_cent.write(str(i) + " " + str(store_clo[i]) + "\n")


if __name__ == "__main__":
    clo_centrality()

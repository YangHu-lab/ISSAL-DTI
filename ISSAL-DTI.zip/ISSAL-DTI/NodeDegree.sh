#!/bin/bash

# please confirm cold/warm start in the scenario(e.g. cold start)

cd DTI-Prediction
python create_sample.py --input ../data/DownStreamdata/DTInet.txt --offset 1
#
cd ../SSLPretask
python encode_feature.py --downstream DTI --scenario warm --dataclean 1

python NodeDegree.py --downstream DTI --scenario warm --dataclean 1

python create_dataset.py --input_file ../data/PreTaskdata/NodeDegree.txt

cd ../ISSAL
python Model/train_node_reg.py --train_file ../data/PreTaskdata/NodeDegree_train.txt --test_file ../data/PreTaskdata/NodeDegree_test.txt --save NodeDegree_warm --batch_size 128 --mode 1 --ntask 1 --task 0 --lr 5e-4 --epochs 1 >>   NodeDegree_warm/NodeDegree_warm.log

for ((i = 1; i <= 30; i++)); do
  rnd=$(($RANDOM % 3))
  case $rnd in
  0)
    python Model/train_node_reg.py --train_file ../data/PreTaskdata/NodeDegree_train.txt --test_file ../data/PreTaskdata/NodeDegree_test.txt --save NodeDegree_warm --share NodeDegree_warm --private NodeDegree_warm --batch_size 128 --mode 1  --ntask 1 --task 0 --lr 5e-4 --epochs 1 >> NodeDegree_warm/NodeDegree_warm.log
    ;;
  1)
    python Model/train_node_reg.py --train_file ../data/PreTaskdata/NodeDegree_train.txt --test_file ../data/PreTaskdata/NodeDegree_test.txt --save NodeDegree_warm --share NodeDegree_warm --private NodeDegree_warm --batch_size 128 --mode 1  --ntask 1 --task 0 --lr 5e-4 --epochs 1 >> NodeDegree_warm/NodeDegree_warm.log
    ;;
  2)
    python Model/train_node_reg.py --train_file ../data/PreTaskdata/NodeDegree_train.txt --test_file ../data/PreTaskdata/NodeDegree_test.txt --save NodeDegree_warm --share NodeDegree_warm --private NodeDegree_warm --batch_size 128 --mode 1  --ntask 1 --task 0 --lr 5e-4 --epochs 1 >> NodeDegree_warm/NodeDegree_warm.log
    ;;
  esac
done

python Model/GetFeature.py --model NodeDegree_warm --length 1 --save NodeDegree_warm

cd ../DTI-Prediction

python warm_start.py --input_file ../data/DownStreamdata/DTInet_sample.txt --feature ../ISSAL/NodeDegree_warm/feature_NodeDegree_warm.pt --lr 0.002 --epochs 30 --save DTInet/NodeDegree_warm >>Warm_Start/NodeDegree_warm

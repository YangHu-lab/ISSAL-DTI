#!/bin/bash

# please confirm cold/warm start in the scenario(e.g. cold start)

cd DTI-Prediction
python create_sample.py --input ../data/DownStreamdata/DTInet.txt --offset 1

cd ../SSLPretask

python encode_feature.py --downstream DTI --scenario warm --dataclean 1

python PathGlobal.py --downstream DTI --scenario warm --dataclean 1

python create_dataset.py --input_file ../data/PreTaskdata/PathGlobal.txt

cd ../ISSAL
python Model/train_class.py --train_file ../data/PreTaskdata/PathGlobal.txt --test_file ../data/PreTaskdata/PathGlobal_test.txt --save PathGlobal_warm --batch_size 128 --sub 1 --length 2 --nclass 4 --ntask 1 --task 0 --lr 5e-4 --epochs 1 >>PathGlobal_warm/PathGlobal_warm.log

for ((i = 1; i <= 30; i++)); do
  rnd=$(($RANDOM % 3))
  case $rnd in
  0)
    python Model/train_class.py --train_file ../data/PreTaskdata/PathGlobal_train.txt --test_file ../data/PreTaskdata/PathGlobal_test.txt --save PathGlobal_warm --share PathGlobal_warm --private PathGlobal_warm --batch_size 128 --sub 1 --length 2 --nclass 4 --ntask 1 --task 0 --lr 5e-4 --epochs 1 >>PathGlobal_warm/PathGlobal_warm.log
    ;;
  1)
    python Model/train_class.py --train_file ../data/PreTaskdata/PathGlobal_train.txt --test_file ../data/PreTaskdata/PathGlobal_test.txt --save PathGlobal_warm --share PathGlobal_warm --private PathGlobal_warm --batch_size 128 --sub 1 --length 2 --nclass 4 --ntask 1 --task 0 --lr 5e-4 --epochs 1 >>PathGlobal_warm/PathGlobal_warm.log
    ;;
  2)
    python Model/train_class.py --train_file ../data/PreTaskdata/PathGlobal_train.txt --test_file ../data/PreTaskdata/PathGlobal_test.txt --save PathGlobal_warm --share PathGlobal_warm --private PathGlobal_warm --batch_size 128 --sub 1 --length 2 --nclass 4 --ntask 1 --task 0 --lr 5e-4 --epochs 1 >>PathGlobal_warm/PathGlobal_warm.log
    ;;
  esac
done

python Model/GetFeature.py --model PathGlobal_warm --length 1 --save PathGlobal_warm

cd ../DTI-Prediction

python warm_start.py --input_file ../data/DownStreamdata/DTInet_sample.txt --feature ../ISSAL/PathGlobal_warm/feature_PathGlobal_warm.pt --lr 0.002 --epochs 30 --save DTInet/PathGlobal_warm >>Warm_Start/PathGlobal_warm

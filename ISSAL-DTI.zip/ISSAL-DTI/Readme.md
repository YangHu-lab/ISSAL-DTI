## Requirements

ISSAL-DTI is tested to work under:

- Python 3.7.7
- numpy 1.16.1
- torch 1.6.0

# Contacts

If you have any questions or comments, please feel free to email: [zhangshihua@scuec.edu.cn] or [2023120488@mail.scuec.edu.cn](mailto:jicheng@hnu.edu.cn).
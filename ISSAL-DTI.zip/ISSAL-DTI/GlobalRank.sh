#!/bin/bash

# please confirm cold/warm start in the scenario(e.g. cold start)

cd DTI-Prediction
python create_sample.py --input ../data/DownStreamdata/DTInet.txt --offset 1
#
cd ../SSLPretask
#
python encode_feature.py --downstream DTI --scenario warm --dataclean 1

python GlobalRank.py --downstream DTI --scenario warm --dataclean 1

python create_dataset.py --input_file ../data/PreTaskdata/GlobalRank.txt

cd ../ISSAL
python Model/train_network_reg.py --train_file ../data/PreTaskdata/GlobalRank_train.txt --test_file ../data/PreTaskdata/GlobalRank_test.txt --save GlobalRank_warm --batch_size 128 --mode 1 --nclass 4 --ntask 1 --task 0 --lr 5e-4 --epochs 1 >>GlobalRank_warm/GlobalRank_warm.log

for ((i = 1; i <= 30; i++)); do
  rnd=$(($RANDOM % 3))
  case $rnd in
  0)
    python Model/train_network_reg.py --train_file ../data/PreTaskdata/GlobalRank_train.txt --test_file ../data/PreTaskdata/GlobalRank_test.txt --save GlobalRank_warm --share GlobalRank_warm --private GlobalRank_warm --batch_size 128 --mode 1 --nclass 4 --ntask 1 --task 0 --lr 5e-4 --epochs 1 >>GlobalRank_warm/GlobalRank_warm.log
    ;;
  1)
    python Model/train_network_reg.py --train_file ../data/PreTaskdata/GlobalRank_train.txt --test_file ../data/PreTaskdata/GlobalRank_test.txt --save GlobalRank_warm --share GlobalRank_warm --private GlobalRank_warm --batch_size 128 --mode 1 --nclass 4 --ntask 1 --task 0 --lr 5e-4 --epochs 1 >>GlobalRank_warm/GlobalRank_warm.log
    ;;
  2)
    python Model/train_network_reg.py --train_file ../data/PreTaskdata/GlobalRank_train.txt --test_file ../data/PreTaskdata/GlobalRank_test.txt --save GlobalRank_warm --share GlobalRank_warm --private GlobalRank_warm --batch_size 128 --mode 1 --nclass 4 --ntask 1 --task 0 --lr 5e-4 --epochs 1 >>GlobalRank_warm/GlobalRank_warm.log
    ;;
  esac
done
#
###
python Model/GetFeature.py --model GlobalRank_warm --length 1 --save GlobalRank_warm

cd ../DTI-Prediction

python warm_start.py --input_file ../data/DownStreamdata/DTInet_sample.txt --feature ../ISSAL/GlobalRank_warm/feature_GlobalRank_warm.pt --lr 0.002 --epochs 30 --save DTInet/GlobalRank_warm >>Warm_Start/GlobalRank_warm

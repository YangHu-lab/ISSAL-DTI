import numpy as np
#垂直拼接
#
# def main():
#     # 设置文件路径
#     path = '../data/BioHNsdata/Luo/'
#     output_path_ABC = '../data/BioHNsdata/Luo/BIONTs.txt'
#
#     # 读取矩阵数据的函数
#     def load_matrix(file_path):
#         with open(file_path, 'r') as f:
#             data = f.readlines()
#         matrix = np.zeros((len(data), len(data[0].split())))
#         for i, line in enumerate(data):
#             matrix[i] = np.array(line.split())
#         return matrix
#
#     # 加载矩阵数据
#     A = load_matrix(path + "A.txt")   # 假设 drugdrug 是 A
#     B = load_matrix(path + "B.txt")  # 假设 drugProtein 是 B
#     C = load_matrix(path + "C.txt")  # 假设 drugDisease 是 C
#
#     # 拼接矩阵：A 的下方拼接 B，再将 B 的下方拼接 C
#     ABC_matrix = np.vstack([A, B, C])
#
#     # 将结果矩阵ABC保存为文本文件
#     np.savetxt(output_path_ABC, ABC_matrix, fmt='%d')
#     print(f"ABC Matrix saved to {output_path_ABC}")
#
# if __name__ == "__main__":
#     main()

# import numpy as np
#
# def main():
#     # 设置文件路径
#     path = '../data/BioHNsdata/Luo/'
#
#     # 读取矩阵数据的函数
#     def load_matrix(file_path):
#         with open(file_path, 'r') as f:
#             data = f.readlines()
#         matrix = np.zeros((len(data), len(data[0].split())))
#         for i, line in enumerate(data):
#             matrix[i] = np.array(line.split())
#         return matrix
#
#     # 加载矩阵数据
#     # A = load_matrix(path + "A.txt")   # 假设 drugdrug 是 A
#     B = load_matrix(path + "BIONTs.txt")  # 假设 drugProtein 是 B
#     # C = load_matrix(path + "C.txt")  # 假设 drugDisease 是 C
#
#     # 打印矩阵的维度
#     # print(f"Matrix A dimensions: {A.shape}")
#     print(f"Matrix B dimensions: {B.shape}")
#     # print(f"Matrix C dimensions: {C.shape}")
#
# if __name__ == "__main__":
#     main()
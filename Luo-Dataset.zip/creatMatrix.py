# A矩阵——最上方的一列
# import numpy as np
#
# def main():
#     # 路径设置
#     path = '../data/BioHNsdata/Luo/'
#     output_path = '../data/BioHNsdata/Luo/A.txt'  # 修改为保存的文件路径
#
#     # 读取矩阵数据
#     def load_matrix(file_path):
#         with open(file_path, 'r') as f:
#             data = f.readlines()
#         matrix = np.zeros((len(data), len(data[0].split())))
#         for i, line in enumerate(data):
#             matrix[i] = np.array(line.split())
#         return matrix
#
#     # 加载3个矩阵
#     drugdrug = load_matrix(path + "drugdrug.txt")
#     drugprotein = load_matrix(path + "drugProtein.txt")
#     drugdisease = load_matrix(path + "drugDisease.txt")
#
#     # 打印矩阵的形状，确保维度一致
#     print(f"drugdrug shape: {drugdrug.shape}")
#     print(f"drugprotein shape: {drugprotein.shape}")
#     print(f"drugdisease shape: {drugdisease.shape}")
#
#     # 确保所有矩阵的行数一致
#     max_rows = max(
#         drugdrug.shape[0],
#         drugprotein.shape[0],
#         drugdisease.shape[0]
#     )
#
#     # 填充矩阵，确保它们的行数一致
#     def pad_matrix_to_size(matrix, target_rows):
#         current_rows = matrix.shape[0]
#         if current_rows < target_rows:
#             padding = np.zeros((target_rows - current_rows, matrix.shape[1]))  # 填充零
#             matrix = np.vstack([matrix, padding])
#         elif current_rows > target_rows:
#             matrix = matrix[:target_rows, :]  # 如果矩阵行数太多，裁剪
#         return matrix
#
#     # 填充矩阵，确保它们的行数一致
#     drugdrug = pad_matrix_to_size(drugdrug, max_rows)
#     drugprotein = pad_matrix_to_size(drugprotein, max_rows)
#     drugdisease = pad_matrix_to_size(drugdisease, max_rows)
#
#     # 拼接矩阵 A（drugdrug + drugprotein + drugdisease）
#     A_matrix = np.hstack([drugdrug, drugprotein, drugdisease])
#
#     # 将矩阵保存为文本文件
#     np.savetxt(output_path, A_matrix, fmt='%d')  # 将矩阵保存为整数格式的文本文件
#     print(f"A Matrix saved to {output_path}")
#
#
# if __name__ == "__main__":
#     main()

# B矩阵——中间的一列
# import numpy as np
#
# def main():
#     # 路径设置
#     path = '../data/BioHNsdata/Luo/'
#     output_path_B = '../data/BioHNsdata/Luo/B.txt'  # 修改为保存矩阵B的文件路径
#
#     # 读取矩阵数据
#     def load_matrix(file_path):
#         with open(file_path, 'r') as f:
#             data = f.readlines()
#         matrix = np.zeros((len(data), len(data[0].split())))
#         for i, line in enumerate(data):
#             matrix[i] = np.array(line.split())
#         return matrix
#
#     # 加载矩阵 drugprotein, proteinprotein, proteindisease
#     drugprotein = load_matrix(path + "drugProtein.txt")
#     proteinprotein = load_matrix(path + "proteinProtein.txt")
#     proteindisease = load_matrix(path + "proteinDisease.txt")
#
#     # 打印矩阵的形状，确保维度一致
#     print(f"drugprotein shape: {drugprotein.shape}")
#     print(f"proteinprotein shape: {proteinprotein.shape}")
#     print(f"proteindisease shape: {proteindisease.shape}")
#
#     # 确保所有矩阵的行数一致
#     max_rows_B = max(
#         drugprotein.T.shape[0],
#         proteinprotein.shape[0],
#         proteindisease.shape[0]
#     )
#
#     # 填充矩阵，确保它们的行数一致
#     def pad_matrix_to_size(matrix, target_rows):
#         current_rows = matrix.shape[0]
#         if current_rows < target_rows:
#             padding = np.zeros((target_rows - current_rows, matrix.shape[1]))  # 填充零
#             matrix = np.vstack([matrix, padding])
#         elif current_rows > target_rows:
#             matrix = matrix[:target_rows, :]  # 如果矩阵行数太多，裁剪
#         return matrix
#
#     # 填充矩阵，确保它们的行数一致
#     drugprotein = pad_matrix_to_size(drugprotein, max_rows_B)
#     proteinprotein = pad_matrix_to_size(proteinprotein, max_rows_B)
#     proteindisease = pad_matrix_to_size(proteindisease, max_rows_B)
#
#     # 计算 drugprotein 的转置矩阵
#     drugprotein_T = drugprotein.T
#
#     # 拼接矩阵 B（drugprotein.T + proteinprotein + proteindisease）
#     B_matrix = np.hstack([drugprotein_T, proteinprotein, proteindisease])
#
#     # 将矩阵B保存为文本文件
#     np.savetxt(output_path_B, B_matrix, fmt='%d')  # 保存为整数格式的文本文件
#     print(f"B Matrix saved to {output_path_B}")

# if __name__ == "__main__":
#     main()
# import numpy as np


# C矩阵——最下边的一列
# import numpy as np
#
# def main():
#     # 路径设置
#     path = '../data/BioHNsdata/Luo/'
#     output_path_C = '../data/BioHNsdata/Luo/C.txt'  # 修改为保存矩阵C的文件路径
#
#     # 读取矩阵数据
#     def load_matrix(file_path):
#         with open(file_path, 'r') as f:
#             data = f.readlines()
#         matrix = np.zeros((len(data), len(data[0].split())))
#         for i, line in enumerate(data):
#             matrix[i] = np.array(line.split())
#         return matrix
#
#     # 加载矩阵 drugdisease 和 proteindisease
#     drugdisease = load_matrix(path + "drugDisease.txt")
#     proteindisease = load_matrix(path + "proteinDisease.txt")
#
#     # 打印矩阵的形状，确保维度一致
#     print(f"drugdisease shape: {drugdisease.shape}")
#     print(f"proteindisease shape: {proteindisease.shape}")
#
#     # 获取 drugdisease 转置后的行数
#     rows_disease = drugdisease.T.shape[0]
#
#     # 填充矩阵，确保它们的行数一致
#     def pad_matrix_to_size(matrix, target_rows):
#         current_rows = matrix.shape[0]
#         if current_rows < target_rows:
#             padding = np.zeros((target_rows - current_rows, matrix.shape[1]))  # 填充零
#             matrix = np.vstack([matrix, padding])
#         elif current_rows > target_rows:
#             matrix = matrix[:target_rows, :]  # 如果矩阵行数太多，裁剪
#         return matrix
#
#     # 填充 proteindisease 矩阵，确保它们的行数一致
#     proteindisease = pad_matrix_to_size(proteindisease, rows_disease)
#
#     # 计算 drugdisease 的转置矩阵
#     drugdisease_T = drugdisease.T
#
#     # 计算 proteindisease 的转置矩阵
#     proteindisease_T = proteindisease.T
#
#     # 创建补全矩阵：行数与 drugdisease_T 相同，列数与 proteindisease_T 相同
#     padding_matrix = np.zeros_like(proteindisease_T)
#
#     # 拼接矩阵 C（drugdisease.T + proteindisease.T + padding_matrix）
#     C_matrix = np.hstack([drugdisease_T, proteindisease_T, padding_matrix])
#
#     # 将矩阵C保存为文本文件
#     np.savetxt(output_path_C, C_matrix, fmt='%d')  # 保存为整数格式的文本文件
#     print(f"C Matrix saved to {output_path_C}")
#
# if __name__ == "__main__":
#     main()



#检查形状
# import numpy as np
#
# def main():
#     # 设置文件路径
#     path = '../data/BioHNsdata/Luo/'
#
#     # 读取矩阵数据的函数
#     def load_matrix(file_path):
#         with open(file_path, 'r') as f:
#             data = f.readlines()
#         matrix = np.zeros((len(data), len(data[0].split())))
#         for i, line in enumerate(data):
#             matrix[i] = np.array(line.split())
#         return matrix
#
#     # 加载矩阵数据
#     # A = load_matrix(path + "A.txt")   # 假设 drugdrug 是 A
#     B = load_matrix(path + "B.txt")  # 假设 drugProtein 是 B
#     # C = load_matrix(path + "C.txt")  # 假设 drugDisease 是 C
#
#     # 打印矩阵的维度
#     # print(f"Matrix A dimensions: {A.shape}")
#     print(f"Matrix B dimensions: {B.shape}")
#     # print(f"Matrix C dimensions: {C.shape}")
#
# if __name__ == "__main__":
#     main()

